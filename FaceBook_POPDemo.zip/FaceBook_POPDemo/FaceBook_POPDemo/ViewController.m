//
//  ViewController.m
//  FaceBook_POPDemo
//
//  Created by lc-macbook pro on 2018/1/17.
//  Copyright © 2018年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "ViewController.h"

#import "POPBasicAnimationExample.h"
#import "POPSpringAnimationExample.h"
#import "POPDecayAnimationExample.h"
#import "POPCustomAnimationExample.h"


/**
 STATICPOPSpringAnimation  有弹性效果的动画类（个人比较喜欢这个）
 POPBasicAnimation 基本动画类
 POPDecayAnimation 衰减动画类
 POPCustomAnimation 可以自定义动画的类
 **/

static NSString *STATIC_POPSpringAnimation = @"有弹性效果的动画类";
static NSString *STATIC_POPBasicAnimation = @"基本动画类";
static NSString *STATIC_POPDecayAnimation = @"衰减动画类";
static NSString *STATIC_POPCustomAnimation = @"可以自定义动画的类";

@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>

@property (nonatomic, strong) UITableView *listTable;
@property (nonatomic, strong) NSArray *tbDataArray;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    self.tbDataArray = @[@{@"class":NSStringFromClass([POPBasicAnimationExample class]),
                           @"title":STATIC_POPBasicAnimation},
                         
                         @{@"class":NSStringFromClass([POPSpringAnimationExample class]),
                           @"title":STATIC_POPSpringAnimation},
                         
                         @{@"class":NSStringFromClass([POPDecayAnimationExample class]),
                           @"title":STATIC_POPDecayAnimation},
                         
                         @{@"class":NSStringFromClass([POPCustomAnimationExample class]),
                           @"title":STATIC_POPCustomAnimation}];
    
    self.listTable = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) style:UITableViewStyleGrouped];
    [self.view addSubview:self.listTable];
    
    self.listTable.delegate = self;
    self.listTable.dataSource = self;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.tbDataArray.count;
}

 - (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
     UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cellID"];
     if (cell == nil) {
         cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"CellID"];
     }
     NSDictionary *dict = self.tbDataArray[indexPath.row];
     cell.textLabel.text = dict[@"title"];
     cell.detailTextLabel.text = dict[@"class"];
     return cell;
 }

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSDictionary *dict = self.tbDataArray[indexPath.row];
    UIViewController *exampleVC = [[NSClassFromString(dict[@"class"]) alloc]init];
    [self.navigationController pushViewController:exampleVC animated:YES];
    
    exampleVC.title = dict[@"title"];
    exampleVC.navigationItem.prompt = dict[@"class"];
}

/*
 // Override to support conditional editing of the table view.
 - (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the specified item to be editable.
 return YES;
 }
 */

/*
 // Override to support editing the table view.
 - (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
 if (editingStyle == UITableViewCellEditingStyleDelete) {
 // Delete the row from the data source
 [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
 } else if (editingStyle == UITableViewCellEditingStyleInsert) {
 // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
 }
 }
 */

/*
 // Override to support rearranging the table view.
 - (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
 }
 */

/*
 // Override to support conditional rearranging of the table view.
 - (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
 // Return NO if you do not want the item to be re-orderable.
 return YES;
 }
 */

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
