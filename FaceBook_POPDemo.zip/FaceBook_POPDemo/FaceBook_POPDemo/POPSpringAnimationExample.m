//
//  POPSpringAnimationExample.m
//  FaceBook_POPDemo
//
//  Created by lc-macbook pro on 2018/1/17.
//  Copyright © 2018年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "POPSpringAnimationExample.h"

@interface POPSpringAnimationExample ()

@end

@implementation POPSpringAnimationExample

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (void)tapGestureAction:(UITapGestureRecognizer*)tap {
    //用POPSpringAnimation 让viewBlue实现弹性放大缩小的效果
    POPSpringAnimation *springAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPLayerSize];
    
    CGRect rect = self.carImageView.frame;
    if (rect.size.width==100) {
        springAnimation.toValue = [NSValue valueWithCGSize:CGSizeMake(300, 300)];
    }
    else{
        springAnimation.toValue = [NSValue valueWithCGSize:CGSizeMake(100, 100)];
    }
    
    
    //弹性值
    springAnimation.springBounciness = 20.0;
    //弹性速度
    springAnimation.springSpeed = 20.0;
    
    [self.carImageView.layer pop_addAnimation:springAnimation forKey:@"changesize"];
    
}

@end
