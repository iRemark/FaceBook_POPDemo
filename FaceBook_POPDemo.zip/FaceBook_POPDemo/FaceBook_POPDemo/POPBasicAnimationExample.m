//
//  POPBasicAnimationExample.m
//  FaceBook_POPDemo
//
//  Created by lc-macbook pro on 2018/1/17.
//  Copyright © 2018年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "POPBasicAnimationExample.h"

@interface POPBasicAnimationExample ()

@end

@implementation POPBasicAnimationExample

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
    
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
    
    UIPanGestureRecognizer *gesture = [[UIPanGestureRecognizer alloc] init];
    [gesture addTarget:self action:@selector(changeSize:)];
    [self.view addGestureRecognizer:gesture];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)tapGestureAction:(UITapGestureRecognizer*)tap {
    
    POPBasicAnimation *anim = [POPBasicAnimation animationWithPropertyNamed:kPOPViewAlpha];
    
    anim.timingFunction = [CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut];
    
    float alpha = self.carImageView.alpha;
    if (alpha == 1.0) {
        anim.toValue = @(0.0);
        
    }else{
        anim.toValue = @(1.0);
    }
    
    [self.carImageView pop_addAnimation:anim forKey:@"alpha"];
    
}






- (void)changeSize:(UIPanGestureRecognizer*)tap{
    
    POPSpringAnimation *springAnimation = [POPSpringAnimation animationWithPropertyNamed:kPOPViewFrame];
    
    CGPoint point = [tap locationInView:self.view];
    
    springAnimation.toValue = [NSValue valueWithCGRect:CGRectMake(0, 0, point.x, point.y)];
    
    
    //弹性值
    springAnimation.springBounciness = 20.0;
    //弹性速度
    springAnimation.springSpeed = 20.0;
    
    [self.carImageView pop_addAnimation:springAnimation forKey:@"changeframe"];
    
}

@end
