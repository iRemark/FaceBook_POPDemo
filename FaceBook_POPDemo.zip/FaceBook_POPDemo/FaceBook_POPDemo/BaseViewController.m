//
//  BaseViewController.m
//  FaceBook_POPDemo
//
//  Created by lc-macbook pro on 2018/1/17.
//  Copyright © 2018年 http://www.cnblogs.com/saytome/. All rights reserved.
//

#import "BaseViewController.h"

@interface BaseViewController ()

@end

@implementation BaseViewController

- (UIImageView *)carImageView {
    if (_carImageView == nil) {
        _carImageView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"1.jpg"]];
        _carImageView.backgroundColor = [UIColor lightGrayColor];
    }
    return _carImageView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.carImageView];
    
    [self addFrame];
    [self addGesture];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)addFrame {
    self.carImageView.frame = CGRectMake(self.view.frame.size.width*0.25,
                                         200, self.view.frame.size.width*0.5, 200);
}

- (void)addGesture {
    self.carImageView.userInteractionEnabled = YES;
    UITapGestureRecognizer *gestureForSpring = [[UITapGestureRecognizer alloc] init];
    [gestureForSpring addTarget:self action:@selector(tapGestureAction:)];
    [self.carImageView addGestureRecognizer:gestureForSpring];
}

- (void)tapGestureAction:(id)sender {
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
